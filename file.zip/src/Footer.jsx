import 'boxicons/css/boxicons.min.css';

const Footer = () => {
    return (
        <footer className="bg-blue-500 text-white p-4 font-bold">
            <div className="container mx-auto flex justify-between items-center">
                <div className="text-sm">
                    &copy; 2024 <span className='text-gray-200'>Bencana.Help</span>. All rights reserved.
                </div>
            </div>
        </footer>
    );
}

export default Footer;
