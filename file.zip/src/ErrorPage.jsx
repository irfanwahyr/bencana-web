const ErrorPage = () => {
    return (
        <div className="">halo</div>
    )
}

export default ErrorPage;