import { useContext } from "react";
import Footer from "./Footer";
import Navbar from "./Navbar";
import { DarkModeContext } from './context/DarkMode';

const About = () => {
    const { isDarkMode } = useContext(DarkModeContext);
    return (
        <div className={` min-h-screen flex flex-col ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-white '}`}>
            <Navbar/>
            <div className="flex-1 bg-cover bg-center">
                <div className="flex justify-center">
                    <div className="container mx-auto text-center p-4">
                        <h1 className="text-4xl font-bold mb-4">Tentang Kami</h1>
                        <div className={` p-6 rounded-lg shadow-lg ${isDarkMode ? 'bg-slate-600 text-white' : 'bg-white'}`}>
                            <p className="mb-4">
                                Selamat datang di situs bantuan bencana kami. Kami adalah organisasi yang berdedikasi untuk membantu korban bencana alam dengan menyediakan informasi terkini, sumber daya, dan dukungan.
                            </p>
                            <p className="mb-4">
                                Misi kami adalah untuk memberikan bantuan cepat dan efisien kepada mereka yang terkena dampak bencana alam. Kami bekerja sama dengan berbagai organisasi lokal dan internasional untuk memastikan bahwa bantuan yang dibutuhkan segera sampai ke tangan yang membutuhkan.
                            </p>
                            <p className="mb-4">
                                Pada website ini, Anda dapat menemukan informasi tentang bencana alam terkini, panduan evakuasi, dan cara-cara untuk mendapatkan bantuan. Kami juga menyediakan platform bagi sukarelawan yang ingin terlibat dalam upaya bantuan bencana.
                            </p>
                            <p className="mb-4">
                                Kami percaya bahwa dengan bekerja sama, kita dapat mengurangi dampak bencana alam dan membantu mereka yang terkena dampak untuk pulih dengan lebih cepat.
                            </p>
                            <p>
                                Terima kasih telah mengunjungi situs kami. Jika Anda memiliki pertanyaan atau membutuhkan bantuan lebih lanjut, jangan ragu untuk menghubungi kami.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <Footer/>
        </div>
    );
}

export default About;
